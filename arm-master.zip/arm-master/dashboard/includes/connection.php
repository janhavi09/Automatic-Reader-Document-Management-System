<?php
$conn = mysqli_connect("localhost","root","root","arm" ) or die ("error" . mysqli_error($conn));
?>
